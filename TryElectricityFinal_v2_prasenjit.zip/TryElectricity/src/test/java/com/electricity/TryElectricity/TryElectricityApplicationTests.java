package com.electricity.TryElectricity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TryElectricityApplicationTests {

	@Test
	void contextLoads() {
	}

}
